<?php $__env->startSection('content'); ?>
	<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
	<?php endif; ?>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-10">

				<div class="card info">

					<div class="card-header">Listing Trainings to Register

						<form method="get" action="<?php echo e(url('registers')); ?>" class="form-inline">
							<?php echo csrf_field(); ?>
							<input type="text" id="txtsearch" name="txtsearch" class="form-control">
							<button type="submmit" class="btn btn-primary">
								<i class="fa fa-search"></i>
							</button>
						</form>

					</div>

					<div class="card-body">
						<?php if(session('success')): ?>
							<div class="alert alert-success">
								<?php echo e(session('success')); ?>

							</div>
						<?php endif; ?>

						<?php if(session('successdelete')): ?>
							<div class="alert alert-warning">
								<?php echo e(session('successdelete')); ?>

							</div>
						<?php endif; ?>

						<table class="table table-striped">
						<thead>
						  <tr>
							<th>ID</th>
							<th>Training Name</th>
							<th>Desc</th>
							<th>Action</th>
							<th></th>
						  </tr>
						</thead>
						<tbody>
						  <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($training['id']); ?></td>
							<td><?php echo e($training['trainingname']); ?></td>
							<td><?php echo e($training['desc']); ?></td>
							<td>
								<a href="<?php echo e(action('RegisterController@show', 
								$training['id'])); ?>" class="btn btn-info">
									  <i class="fa fa-file-text-o"></i>
								  </a>
							</td>
							<td>
								  
							</td>
						  </tr>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tbody>
						</table>
							
					</div>
					<div align="right">
						<?php echo e($trainings->links()); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>












<?php echo $__env->make('layouts.generic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>