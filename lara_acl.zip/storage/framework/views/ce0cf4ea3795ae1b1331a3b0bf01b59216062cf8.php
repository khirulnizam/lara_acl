<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <p>Hello administrator <?php echo e(Auth::user()->name); ?> </p>
                        <br>
					<a href="<?php echo e(url('trainings')); ?>"> Training menus</a>
					<br>
					<a href="<?php echo e(url('trainings/create')); ?>">&nbsp;&nbsp; :: Create Training</a>
					<br>
					<br>
					<br>
					<a href="#"> Registrations Report</a>
					Choose trainings
					<form method="GET" 
					action="<?php echo e(url('registerreports')); ?>" 
					class="form-inline">
					<?php echo csrf_field(); ?>
						<select name="id" class="form-control">
							<?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($training['id']); ?>"> 
							<?php echo e($training['trainingname']); ?> </option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						
						<button type="submit" class="btn btn-info"> 
						Generate </button>
					</form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fancy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>