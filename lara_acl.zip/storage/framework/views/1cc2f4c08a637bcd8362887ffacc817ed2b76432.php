<?php $__env->startSection('content'); ?>
    <div class="col-sm-3 col-md-9">
        <img src="<?php echo e(asset('images/bannerfstm.jpg')); ?>" width="100%">
        <br>
        Faculty of Information & Science Technology<br>
    </div>
    <div class="col-sm-3 col-md-3">
            <form method="post" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="usr">Email:</label>
                    <input type="text" class="form-control" name="email">
                </div>
                <div class="form-group">
                    <label for="pwd">Password:</label>
                    <input type="password" class="form-control" name="password">
                </div>
                <button type="submit" class="btn btn-info"> Login </button>
            </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.generic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>