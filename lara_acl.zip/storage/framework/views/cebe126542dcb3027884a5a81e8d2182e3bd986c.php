<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
				<?php if(Auth::user()->hasRole('admin')): ?>{
				<div align="right">
					<a href="<?php echo e(url('trainings/create')); ?>">Insert </a> ||
					<a href="<?php echo e(url('trainings')); ?>">Listing for Update/Delete</a>
				</div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="alert alert-success">
					<?php echo e(session('success')); ?>

				</div>
			<?php endif; ?>

                <div class="card">
                    <div class="card-header">Training details</div>

                    <div class="card-body">
					<img class="card-img-top" 
					src="<?php echo e(url('storage/uploads/'.$training->filename)); ?>" 
					alt="<?php echo e($training->filename); ?>">
					<a href="<?php echo e(url('storage/uploads/'.$training->filename)); ?>"> Download poster </a>
					<br>
					<br>

					
					Training name <br>
					<h3> <?php echo e($training->trainingname); ?> </h3>
					<br><br>
					Training description <br>
					<strong> <?php echo e($training->desc); ?>  </strong>
					<br><br>
					
					Trainer's name<br>
					<strong> <?php echo e($training->trainer); ?></strong>
					<br><br>
					


                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>