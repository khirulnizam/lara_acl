<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div align="right">
                <a href="<?php echo e(url('trainings/create')); ?>">Insert </a> ||
                <a href="<?php echo e(url('trainings')); ?>">Listing for Update/Delete</a>
            </div>

            <div class="card">
                <div class="card-header">Insert new Training</div>

                <div class="card-body">
                    <h2>Edit Training Record</h2>
                    <br>
                    <form method="post" action="<?php echo e(action('TrainingController@update', $id)); ?>">
                    <?php echo csrf_field(); ?>
                    <input name="_method" type="hidden" value="PATCH">

                            <label for="trainingname">Training Name:</label>
                            <input type="text" class="form-control" name="trainingname"
                                   value="<?php echo e($training->trainingname); ?>">

                            <label for="desc">Description:</label>
                            <input type="text" class="form-control" name="desc"
                                   value="<?php echo e($training->desc); ?>">

                            <label for="trainer">Trainer:</label>
                            <input type="text" class="form-control" name="trainer"
                                   value="<?php echo e($training->trainer); ?>">

                            <button type="submit" class="btn btn-success">Save Update</button>

                    </form>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.generic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>