<?php $__env->startSection('content'); ?>
	<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
	<?php endif; ?>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-10">

				<div class="card info">

					<div class="card-header">Participants registered for Training

					</div>

					<div class="card-body">

						<table class="table table-striped">
						<thead>
						  <tr>
							<th>bil</th>
							<th>Name</th>
							<th>Matrix</th>
							<th>Sign</th>
							<th></th>
						  </tr>
						</thead>
						<tbody>
							<?php $i=1; ?>
						  <?php $__currentLoopData = $registers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo $i; $i++?></td>
							<td><?php echo e($reg['name']); ?></td>
							<td><?php echo e($reg['matrix']); ?></td>
							<td>
								
							</td>
							<td>
								  
							</td>
						  </tr>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tbody>
						</table>
							
					</div>
					<div align="right">
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>












<?php echo $__env->make('layouts.fancy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>