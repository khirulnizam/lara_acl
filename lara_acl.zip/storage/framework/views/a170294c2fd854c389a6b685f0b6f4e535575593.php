<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
			<?php if(session('success')): ?>
				<div class="alert alert-success">
					<?php echo e(session('success')); ?>

				</div>
			<?php endif; ?>

                <div class="card">
                    <div class="card-header">Training details</div>

                    <div class="card-body">
					<img class="card-img-top" 
					src="<?php echo e(url('storage/uploads/'.$training->filename)); ?>" 
					alt="<?php echo e($training->filename); ?>">

					<br>
					<a href="<?php echo e(url('storage/uploads/'.$training->filename)); ?>" target="_blank">
						Download poster </a>
					<br>
					<br>
					
					Training name <br>
					<h3> <?php echo e($training->trainingname); ?> </h3>
					<br><br>
					Training description <br>
					<strong> <?php echo e($training->desc); ?>  </strong>
					<br><br>
					
					Trainer's name<br>
					<strong> <?php echo e($training->trainer); ?></strong>
					<br><br>
					
					<hr>
					
					<h3>Self-registration Form</h3>
					
                    <form method="post" action="<?php echo e(url('registers')); ?>">
                    <?php echo csrf_field(); ?>
                      <label for="trainingname">Name</label>
                      <input type="text" class="form-control" name="name">

                      <label for="desc">Matrix</label>
                      <input type="text" class="form-control" name="matrix">
					  
					  <input type="hidden" class="form-control" 
					  name="training_id" value="<?php echo e($training->id); ?>">

                      <button type="submit" class="btn btn-primary"> 
					  Register myself for this training</button>
                    </form>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fancy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>