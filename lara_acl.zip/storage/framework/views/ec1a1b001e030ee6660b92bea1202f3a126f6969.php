<?php $__env->startSection('content'); ?>
	<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
	<?php endif; ?>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-10">

				<div align="right">

					<a href="<?php echo e(url('trainings/create')); ?>">Insert </a> ||
					<a href="<?php echo e(url('trainings')); ?>">Listing for Update/Delete</a>

				</div>
				<div class="card info">

					<div class="card-header">Listing Trainings for Update/Delete

						<form method="get" action="<?php echo e(url('trainings')); ?>" class="form-inline">
							<?php echo csrf_field(); ?>
							<input type="text" id="txtsearch" name="txtsearch" class="form-control">
							<button type="submmit" class="btn btn-primary">
								<i class="fa fa-search"></i>
							</button>
						</form>

					</div>

					<div class="card-body">
						<?php if(session('success')): ?>
							<div class="alert alert-success">
								<?php echo e(session('success')); ?>

							</div>
						<?php endif; ?>

						<?php if(session('successdelete')): ?>
							<div class="alert alert-warning">
								<?php echo e(session('successdelete')); ?>

							</div>
						<?php endif; ?>

						<table class="table table-striped">
						<thead>
						  <tr>
							<th>ID</th>
							<th>Training Name</th>
							<th>Desc</th>
							<th>Action</th>
							<th></th>
						  	<th></th>
						  </tr>
						</thead>
						<tbody>
						  <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($training['id']); ?></td>
							<td><?php echo e($training['trainingname']); ?></td>
							<td><?php echo e($training['desc']); ?></td>
							  <td>
								  <a href="<?php echo e(action('TrainingController@show',
								$training['id'])); ?>" class="btn btn-info btn-sm">
									  <i class="fa fa-file-text-o"></i>
								  </a>
							  </td>
							  <td><a href="<?php echo e(action('TrainingController@edit', $training['id'])); ?>"
									 class="btn btn-warning btn-sm">
									  <i class="fa fa-edit"></i>
								  </a></td>
							  <td>
								  <form action="<?php echo e(action('TrainingController@destroy', $training['id'])); ?>" method="post">
									  <?php echo csrf_field(); ?>
									  <input name="_method" type="hidden" value="DELETE">
									  <button class="btn btn-danger btn-sm" type="submit">
										  <i class="fa fa-remove"></i>
									  </button>
								  </form>
							</td>

						  </tr>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  
						<tbody>
						</table>
						<div class="text-right">
						
							<?php echo e($trainings->links()); ?>

						</div>
							
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>












<?php echo $__env->make('layouts.fancy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>