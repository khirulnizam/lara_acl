<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div align="right">
                    <a href="<?php echo e(url('trainings/create')); ?>">Insert </a> ||
                    <a href="<?php echo e(url('trainings')); ?>">Listing for Update/Delete</a>
                </div>

                <div class="card">
                    <div class="card-header">Insert new Training</div>

                    <div class="card-body">

                    <form method="post" action="<?php echo e(url('trainings')); ?>" 
					enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <label for="trainingname">Training Name</label>
                      <input type="text" class="form-control" name="trainingname">

                      <label for="desc">Description</label>
                      <input type="text" class="form-control" name="desc">

                      <label for="trainer">Trainer</label>
                      <input type="text" class="form-control" name="trainer">
					  
                      <label for="author">Upload poster image (jpg/png)</label>
						<input type="file" class="form-control" name="filename">
						<br>
					  
					  <button type="submit" class="btn btn-primary"> Save new Training 
					  </button>
                    </form>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>